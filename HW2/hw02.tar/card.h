/*
 	Zac Peterson
	Card.h
	This header file defines the members of the card class which will be used throughout the program
*/
using namespace std;

class card {
public:
	int rank, suit;

	card();
	card(int suit, int card);
};
